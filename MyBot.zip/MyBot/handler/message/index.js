require('dotenv').config()
const { decryptMedia, Client } = require('@open-wa/wa-automate')
const moment = require('moment-timezone')
moment.tz.setDefault('Asia/Jakarta').locale('id')
const { cariKasar, downloader, cekResi, removebg, urlShortener, meme, translate, getLocationData, Nulis, Gquotes } = require('../../lib')
const { msgFilter, color, processTime, is } = require('../../utils')
const mentionList = require('../../utils/mention')
const { uploadImages } = require('../../utils/fetcher')
const {
    insert,
    countHit,
    countUsers,
    statCommand
} = require('../../database')
const db = require("quick.db");
const fs = require('fs-extra')
const banned = JSON.parse(fs.readFileSync('.../../settings/banned.json'))

const { menuId, menuEn } = require('./text') // Indonesian & English menu

const appRoot = require('app-root-path')
const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
const db_group = new FileSync(appRoot+'/lib/data/group.json')
const dbs = low(db_group)
dbs.defaults({ group: []}).write()

module.exports = msgHandler = async (client, message) => {
    try {
        const { type, id, from, t, author, content, argv, sender, isGroupMsg, chat, chats, chatId, caption, isMedia, isGif, mimetype, quotedMsg, quotedMsgObj, mentionedJidList } = message
        let { body } = message
        const { name, formattedTitle } = chat
        let { pushname, verifiedName, formattedName } = sender
        pushname = pushname || verifiedName || formattedName // verifiedName is the name of someone who uses a business account
        const botNumber = await client.getHostNumber() + '@c.us'
        const groupId = isGroupMsg ? chat.groupMetadata.id : ''
        const groupAdmins = isGroupMsg ? await client.getGroupAdmins(groupId) : ''
        const groupMembers = isGroupMsg ? await client.getGroupMembersId(groupId) : ''
        const isGroupAdmins = groupAdmins.includes(sender.id) || false
        const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const premiNumber = ['6289508837920@c.us','628xxx@c.us']
		const isPremi = premiNumber.includes(sender.id)
		const report = '6289508837920@c.us'
		const ownerNumber = '6289508837920@c.us'
		const isOwnerBot = ownerNumber.includes(sender.id)
		
        // Bot Prefix
        const prefix = '/'
        body = (type === 'chat' && body.startsWith(prefix)) ? body : (((type === 'image' || type === 'video') && caption) && caption.startsWith(prefix)) ? caption : ''
        const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
        const komando = message.body || message.caption
		const arg = body.substring(body.indexOf(' ') + 1)
        const args = body.trim().split(/ +/).slice(1)
        const isCmd = body.startsWith(prefix)
        const isQuotedImage = quotedMsg && quotedMsg.type === 'image'
        const isQuotedVideo = quotedMsg && quotedMsg.type === 'video'
	    const url = args.length !== 0 ? args[0] : ''
        const uaOverride = process.env.UserAgent
		const pengirim = sender.id
		
		 //Economy System
         let bal = db.fetch(`money_${sender.id}`)
         if (bal === null) bal = 5000;
         let bank = db.fetch(`bank_${sender.id}`)
         if (bank === null) bank = 0;
         let doge = db.fetch(`doge-${sender.id}`)
         if (doge === null) doge = 0;

		//Bot Message
		if (message.type === 'chat') {
            let astri = ['']
            let irtsa = !!new RegExp(astri.join('|')).test(komando.toLowerCase())
            if (irtsa) {
                let data = `Bank:${bank}`;
                fs.writeFileSync(`.../../database/player/${pushname}.json`, data)
            }
        }
		//Function Lol
		const isBanned = banned.includes(pengirim)

        // [BETA] Avoid Spam Message
        if (isCmd && msgFilter.isFiltered(from) && !isGroupMsg) { return console.log(color('[SPAM]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname)) }
        if (isCmd && msgFilter.isFiltered(from) && isGroupMsg) { return console.log(color('[SPAM]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle)) }
        //Chat
        if (!isCmd && !isGroupMsg) { return console.log('[RECV]', color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), 'Message from', color(pushname)) }
        if (!isCmd && isGroupMsg) { return console.log('[RECV]', color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), 'Message from', color(pushname), 'in', color(name || formattedTitle)) }
        if (isCmd && !isGroupMsg) { console.log(color('[EXEC]'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname)) }
        if (isCmd && isGroupMsg) { console.log(color('[EXEC]'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle)) }
	   // [BETA] Avoid Spam Message
        msgFilter.addFilter(from)
		//Filter banned people
		if (isBanned) {
            return console.log(color('[BAN]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
	   }
	   if (isBanned) client.reply(from, 'Kamu Telah Di Ban Dari Bot!', id)
		//close
		switch (command) {
        //Economy
        case 'bal':
            client.reply(from, `*Balance ${pushname}*\n\n*Money:${bal}*\n*Doge Coin:${doge}*\n*Bank:${bank}*`, id)
            break
		//Bersenang Senang Anjas
		case 'nulis':
                var nonOption = quotedMsg ? quotedMsgObj.body : args.join(' ')
                Nulis(nonOption)
                    .then(res => {
                        res.map(link => {
                            client.sendFileFromUrl(from, link, 'nulis.png', `Sudah Siap Gan!`, null, null, true)
                        })
                    })
                    .catch(err => {
                        console.log('[NULIS] Error:', err)
                        client.reply(from, err, id)
                    })
                insert(author, type, content, pushname, from, argv)
                break
		case 'tts':
                var withOption = quotedMsg ? quotedMsgObj.body : args.splice(1).join(' ')
                var tts = require('node-gtts')(args[0])
                tts.save(process.cwd() + '/tts.ogg', withOption, async () => {
                    client.sendPtt(from, './tts.ogg', null)
                })
                insert(author, type, content, pushname, from, argv)
                break
		//Ping Anjay
		case 'ping':
		    await client.sendText(from, `Ping!. timing: ${processTime(t, moment())} second`)
            insert(author, type, content, pushname, from, argv)
        break
        //Donate
        case 'donate':
        case 'donasi':
            client.reply(from, '*Donasi Owner Buat Beli Amer:v*\n\n╭─「 Donasi • Pulsa 」\n│ • 3 [089508837920]\n╰────\n\n╭─「 Donasi • Non Pulsa 」\n│ • Gopay, OVO [089508837920]\n│ • https://saweria.co/adzbot\n╰────', id)
            break
        //Join Cuk
		case 'join':
            if (!isPremi) return client.reply(from, 'Perintah ini hanya untuk premium', id)
            if (args.length == 0) return client.reply(from, `Jika kalian ingin mengundang bot kegroup silahkan invite atau dengan\nketik ${prefix}join [link group]`, id)
            let linkgrup = body.slice(6)
            let islink = linkgrup.match(/(https:\/\/chat.whatsapp.com)/gi)
            let chekgrup = await client.inviteInfo(linkgrup)
            if (!islink) return client.reply(from, 'Maaf link group-nya salah! sialahkan kirim link yang benar', id)
            if (isOwnerBot) {
                await client.joinGroupViaLink(linkgrup)
                      .then(async () => {
                          await client.sendText(from, 'Berhasil join grup via link!')
                          await client.sendText(chekgrup.id, `Hallo Semua Bot Telah Join Menggunakan Link`)
                      })
            } else {
                await client.joinGroupViaLink(linkgrup)
                      .then(async () =>{
                          await client.reply(from, 'Berhasil join grup via link!', id)
                      })
                      .catch(() => {
                          client.reply(from, 'Gagal!', id)
                      })
            }
            break
		// Premium Check Command
		case 'pcheck':
		    if (!isPremi) client.reply(from, 'Anda Bukan Premium', id)
			else {
				client.reply(from, 'Anda Termasuk Premium', id)
			}
			break	    
        // Menu
        case 'menu':
        case 'help':
            let date_ob = new Date();
            let date = ("0" + date_ob.getDate()).slice(-2);
            let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
            let year = date_ob.getFullYear();
            let hours = date_ob.getHours();
            let minutes = date_ob.getMinutes();
            let seconds = date_ob.getSeconds();
            await client.reply(from, menuId.textMenu(pushname, date, month, year, hours, minutes, seconds), id)
            break
		//Report
		case 'report':
		    client.reply(from, "Report Berhasil Dikirim", id)
            await client.sendText(report, `*Report Dari ${pushname}*\nNomor:${sender}\n\nText:${args.join(' ')}`)
        break
		//Sticker Maker
		case 'sticker':
        case 'stiker': {
            if ((isMedia || isQuotedImage) && args.length === 0) {
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
                client.sendImageAsSticker(from, imageBase64).then(() => {
                    client.reply(from, 'Sticker Kamu Sudah Siap!')
                    console.log(`Sticker Processed for ${processTime(t, moment())} Second`)
                })
            } else if (args.length === 1) {
                if (!is.Url(url)) { await client.reply(from, 'Maaf, link yang kamu kirim tidak valid. [Invalid Link]', id) }
                client.sendStickerfromUrl(from, url).then((r) => (!r && r !== undefined)
                    ? client.sendText(from, 'Maaf, link yang kamu kirim tidak memuat gambar. [No Image]')
                    : client.reply(from, 'Sitcker Kamu Sudah Siap!')).then(() => console.log(`Sticker Processed for ${processTime(t, moment())} Second`))
            } else {
                await client.reply(from, 'Tidak ada gambar! Untuk membuka daftar perintah kirim #menu [Wrong Format]', id)
            }
            break
		}
		//Admin Group
		case 'kick':
            if (!isGroupMsg) return client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!isBotGroupAdmins) return client.reply(from, 'Gagal, silahkan tambahkan bot sebagai admin grup! [Bot Not Admin]', id)
            if (mentionedJidList.length === 0) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (mentionedJidList[0] === botNumber) return await client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            await client.sendTextWithMentions(from, `Request diterima, mengeluarkan:\n${mentionedJidList.map(x => `@${x.replace('@c.us', '')}`).join('\n')}`)
            for (let i = 0; i < mentionedJidList.length; i++) {
                if (groupAdmins.includes(mentionedJidList[i])) return await client.sendText(from, 'Gagal, kamu tidak bisa mengeluarkan admin grup.')
                await client.removeParticipant(groupId, mentionedJidList[i])
            }
            break
        case 'promote':
            if (!isGroupMsg) return await client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return await client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!isBotGroupAdmins) return await client.reply(from, 'Gagal, silahkan tambahkan bot sebagai admin grup! [Bot not Admin]', id)
            if (mentionedJidList.length != 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format, Only 1 user]', id)
            if (groupAdmins.includes(mentionedJidList[0])) return await client.reply(from, 'Maaf, user tersebut sudah menjadi admin. [Bot is Admin]', id)
            if (mentionedJidList[0] === botNumber) return await client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            await client.promoteParticipant(groupId, mentionedJidList[0])
            await client.sendTextWithMentions(from, `Request diterima, menambahkan @${mentionedJidList[0].replace('@c.us', '')} sebagai admin.`)
            break
        case 'demote':
            if (!isGroupMsg) return client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!isBotGroupAdmins) return client.reply(from, 'Gagal, silahkan tambahkan bot sebagai admin grup! [Bot not Admin]', id)
            if (mentionedJidList.length !== 1) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format, Only 1 user]', id)
            if (!groupAdmins.includes(mentionedJidList[0])) return await client.reply(from, 'Maaf, user tersebut tidak menjadi admin. [user not Admin]', id)
            if (mentionedJidList[0] === botNumber) return await client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            await client.demoteParticipant(groupId, mentionedJidList[0])
            await client.sendTextWithMentions(from, `Request diterima, menghapus jabatan @${mentionedJidList[0].replace('@c.us', '')}.`)
            break
        case 'bye':
            if (!isGroupMsg) return client.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup! [Group Only]', id)
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            client.sendText(from, 'Good bye... ( ⇀‸↼‶ )').then(() => client.leaveGroup(groupId))
            break
        case 'del':
            if (!isGroupAdmins) return client.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup! [Admin Group Only]', id)
            if (!quotedMsg) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            if (!quotedMsgObj.fromMe) return client.reply(from, 'Maaf, format pesan salah silahkan periksa menu. [Wrong Format]', id)
            client.deleteMessage(quotedMsgObj.chatId, quotedMsgObj.id, false)
            break
		//Owner Only
		case 'bc': //untuk broadcast atau promosi
            if (!isOwnerBot) return client.reply(from, 'Perintah ini hanya untuk Owner bot!', id)
            if (args.length == 0) return client.reply(from, `Untuk broadcast ke semua chat ketik:\n${prefix}bc [isi chat]`)
            let msg = body.slice(4)
            const chatz = await client.getAllChatIds()
            for (let idk of chatz) {
                var cvk = await client.getChatById(idk)
                if (!cvk.isReadOnly) client.sendText(idk, `〘 *A D I P  B C* 〙\n\n${msg}`)
                if (cvk.isReadOnly) client.sendText(idk, `〘 *A D I P  B C* 〙\n\n${msg}`)
            }
            client.reply(from, 'Broadcast Success!', id)
            break
        case 'leaveall': //mengeluarkan bot dari semua group serta menghapus chatnya
            if (!isOwnerBot) return client.reply(from, 'Perintah ini hanya untuk Owner bot', id)
            const allChatz = await client.getAllChatIds()
            const allGroupz = await client.getAllGroups()
            for (let gclist of allGroupz) {
                await client.sendText(gclist.contact.id, `Maaf bot sedang pembersihan, total chat aktif : ${allChatz.length}`)
                await client.leaveGroup(gclist.contact.id)
                await client.deleteChat(gclist.contact.id)
            }
            client.reply(from, 'Success leave all group!', id)
            break
        case 'clearall': //menghapus seluruh pesan diakun bot
            if (!isOwnerBot) return client.reply(from, 'Perintah ini hanya untuk Owner bot', id)
            const allChatx = await client.getAllChats()
            for (let dchat of allChatx) {
                await client.deleteChat(dchat.id)
            }
            client.reply(from, 'Succes clear all chat!', id)
            break
		case 'ban':
            if (!isOwnerBot) return client.reply(from, 'Perintah ini hanya untuk Owner bot!', id)
            if (args.length == 0) return client.reply(from, `Untuk banned seseorang agar tidak bisa menggunakan commands\n\nCaranya ketik: \n${prefix}ban add 628xx --untuk mengaktifkan\n${prefix}ban del 628xx --untuk nonaktifkan\n\ncara cepat ban banyak digrup ketik:\n${prefix}ban @tag @tag @tag`, id)
            if (args[0] == 'add') {
                banned.push(args[1]+'@c.us')
                fs.writeFileSync('./settings/banned.json', JSON.stringify(banned))
                client.sendTextWithMentions(from, `Success banned @${mentionedJidList[0].replace('@c.us', '')}!`)
            } else
            if (args[0] == 'del') {
                let xnxx = banned.indexOf(args[1]+'@c.us')
                banned.splice(xnxx,1)
                fs.writeFileSync('./settings/banned.json', JSON.stringify(banned))
                client.sendTextWithMentions(from, `Success unbanned @${mentionedJidList[0].replace('@c.us', '')}!`)
            } else {
             for (let i = 0; i < mentionedJidList.length; i++) {
                banned.push(mentionedJidList[i])
                fs.writeFileSync('./settings/banned.json', JSON.stringify(banned))
                client.sendTextWithMentions(from, `Success ban @${mentionedJidList[0].replace('@c.us', '')}!`)
                }
            }
            break
        }
    } catch (err) {
        console.log(color('[EROR]', 'red'), err)
        client.reply(from, `[ERROR]${err}`, id)
    }
}