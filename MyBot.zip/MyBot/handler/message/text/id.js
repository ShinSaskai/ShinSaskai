exports.textMenu = (pushname, date, month, year, hours, minutes, seconds) => {
    return `
Hi, ${pushname}! 👋️
*BOT By Pann*
*DATE:${year}/${month}/${date}*
*TIME:${hours}:${minutes}:${seconds}*


~By Pann`
}
