# Whatsapp-Bot

# Open Cmd Ketik
# npm install
# node index.js
